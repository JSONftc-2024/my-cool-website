/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
  } else {
    x.className = "topnav";
  }
}

const getWeather = async () => {
  const w = await (await fetch('https://getweatherfromip.jasonzhu3.repl.co/')).json();

  return {
    city: w.city,
    temp: w.temp.temperature
  }
};

const main = async () => {
  const weather = await getWeather();
  const weatherEle = document.getElementById('weather');

  
  weatherEle.innerText = `${weather.city}, ${weather.temp}°C`;
}

main();


document.getElementById('Overview').onclick = function() {
   document.getElementById('Overview').innerHTML = '<ol><li>html data</li></ol>';
}

document.getElementById('Types').onclick = function() {
   document.getElementById('Types').innerHTML = '<ol><li>html data</li></ol>';
}

document.getElementById('Components').onclick = function() {
   document.getElementById('Components').innerHTML = '<ol><li>html data</li></ol>';
}

document.getElementById('Physics').onclick = function() {
   document.getElementById('Physics').innerHTML = '<ol><li>html data</li></ol>';
}

document.getElementById('Contact').onclick = function() {
   document.getElementById('Contact').innerHTML = '<ol><li>html data</li></ol>';
}
document.getElementById('weather').onclick = function() {
   document.getElementById('weather').innerHTML = '<ol><li>html data</li></ol>';
}